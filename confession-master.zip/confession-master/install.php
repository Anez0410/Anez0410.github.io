<!DOCTYPE HTML>
<html>

<head>
<meta charset="utf-8" />
<title>Confession Installation</title>

<style>
grey {
    color: grey;
}
</style>
</head>

<body>
<h1> Hello! </h1> <br />
<span>Confession installation goes here.</span>
<hr />
<span>
Hello and hello.<br />
Welcome to Confession.<br />
<br />
Now please fill in the <code>config.php</code> with you database data.<br />
Actually the configure is REALLY EASY. (if you have a MySQL server, and MariaDB works I think...)
</span>
<hr />
<span>
Click <a href="install/check.php">here</a> if you have done that <b> and are ready to install</b>.
</span>

</body>

</html>