<?php

if( isset($_POST['target']) )
    include("includes/get_cookie_2.php");
else
    include("includes/get_cookie_1.php");