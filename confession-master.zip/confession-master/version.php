<?php

    $CONF_VERSION = '1.1';
    $CONF_RECENT_CHANGELOG = 'Add support for PHP 7 using PDO.';

?>