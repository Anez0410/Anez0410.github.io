#!/bin/bash

cp config_test.php ../config.php